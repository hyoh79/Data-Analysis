################################################################
#미드슈트에서 주인공 그래프로 시각화
################################################################

# 0. 패키지 다운로드 및 라이브러리 로드
install.packages("igraph")
library(igraph)

# 1. 데이터 로딩
df<-read.csv("ex3. network_suits.csv",header=T) # 미드 슈츠라는 드라마의 인물 관계도 존재하는 파일
df = as.data.frame(df)

# 2. graph.data.frame을통해, igraph를 실행하고 변환
df = graph.data.frame(df, directed = FALSE)


# 3. 그래프 출력으로 결과 확인

# 방법1) 기본 그래프
plot(df, vertex.size = 10, vertex.label = V(df)$name)


# 방법2) degree가 큰 노드들을 부각
# plot(df,
#      vertex.label = V(df)$name,
#      vertex.size = degree(df)*3 # 집중도 높은 주인공의 원 크기를 3배 해줌
# )
# 
# # 방법3) 원형 네트워크 그래프
# plot(df, layout=layout.circle, vertex.size = 10, vertex.label = V(df)$name)
# plot(df, layout=layout.circle, vertex.size=degree(df)*3, vertex.label=V(df)$name)
