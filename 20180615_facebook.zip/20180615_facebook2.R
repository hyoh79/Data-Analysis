rm(list=ls())
library(KoNLP) 
library(wordcloud)
library(Rfacebook)

library(qdap)

#contrib01. pacman이라는 패키지를 추가합니다. install.packages() + library()
# if (!require("pacman")) {install.packages("pacman")}
# pacman::p_load_gh("trinker/qdap")

facebook_crawling <- function(token, page, output) {
  # ABC News 페이스북 데이터 수집
  facebookData <- getPage(page, token, n=100)
  # ABC News 뉴스피드 데이터를 파일에 저장
  write(facebookData$message, output)
}

# ABC News 페이지에서 데이터 수집
page <- "ABCNews" 		       # ABC News 페이지 ID
token <- "EAACEdEose0cBAGOyczNyuFZAETGMZCkNZCPy09KzEbbQWMPFfBkpO67HJcfllISSgmweZBCKeWGaYlFQl1KmThLgsoI8J7x9WbLkYY6xfEIBrfSsxXL8gCv0g9wSbV9gZAXR5vCZAJ8xA5M40XRPRuxuvhcvRTmZB6Rt3MnHozliZAm4USsZBaAd5ryB9ZBliVxZCL7QdEZA6ABJQAZDZD"	# 페이스북 개발자 토큰
output <- "abcnews_fb_data.txt"	# 저장할 결과 파일 이름 
facebook_crawling(token, page, output) 

# 텍스트마이닝을 이용한 데이터 정제 및 분석

## 1) 페이스북 데이터 읽어오기
facebookPosts <- readLines(output)
## 2) NA 데이터 제거
facebookPosts <- facebookPosts[!is.na(facebookPosts)]
## 3) 명사 추출
facebookWords <- sapply(facebookPosts,extractNoun,USE.NAMES=F)
## 4) 특수문자, 숫자, 공백, 불필요한 단어 제거
interest<-gsub("[[:punct:][:digit:][:space:]]", "", unlist(facebookWords))


#contrib03-1 stopwords가 제외된 단어만을 추출합니다.
sub_interest<-rm_stopwords(interest, stopwords = tm::stopwords("english"))
sub_interest<-unlist(sub_interest)

#contrib03-2 stopwords들의 목록은 이하를 통해 볼 수 있습니다.
library(tm)
head(stopwords(kind = 'en'),10)
write.table(stopwords(kind='en'), file = "general_stopwords.txt")
print(length(stopwords(kind='en')))#174개

# 5) 단어길이 3개 보다 큰 단어만 통과
#contrib03 namespace collision으로 인해 문제가 발생할 경우, 아래와 같이 수정합니다.
interest <- base::Filter(function(x) {nchar(x) > 3}, interest)
sub_interest <- base::Filter(function(x) {nchar(x) > 3}, sub_interest)
# 6) 데이터 빈도 분석
word_count<-table(interest)
sub_word_count <- table(sub_interest)
head(sort(word_count, decreasing = T), 30)
head(sort(sub_word_count, decreasing = T), 30)

# 분석 결과 저장
write.table(sort(sub_word_count, decreasing = T), file = "abcnews_interest.txt")

# 시각화
# 최소 빈도수 min.freq 이상인 단어를 워드클라우드로 시각화
# 또 다른 새로운 위도우 창에 시각화 후, png사진으로 저장

windows()
windowsFonts(font=windowsFont("맑은 고딕"))

par(mfrow=c(1,2))
wordcloud(names(word_count),freq=word_count, scale=c(3,0.5),
          rot.per = 0.25,min.freq = 5, random.order = F, 
          colors = brewer.pal(8, "Blues"),family="font")
wordcloud(names(sub_word_count), freq=sub_word_count,scale=c(3,0.5), 
          rot.per = 0.25, min.freq = 4, random.order = F, 
          colors = brewer.pal(8, "Reds"),family="font")


savePlot("C:/Users/ajou/Documents/20180615_facebook/facebook.png", type="png")

# wordcloud(….) - WordCloud 그리는 함수 추가 사용법
# scale : 빈도가 가장 큰 단어와 가장 빈도가 작은 단어 폰트 사이 크기, scale=c(5,0.2),
# per=0.1 : 90도 회전해서 보여줄 단어 비율
# freq=3, max.words=100  : 빈도 3이상, 100미만 단어 표현
# order=F : True(랜덤배치) / False(빈도수가 큰단어를 중앙에 배치)
# color=T : True(색상랜덤) / False(빈도수순으로 색상표현)
# colors=brewer.pal(11, “Paired”) : 11은 사용할 색상개수, 두번째는 색상타입이름, 색상타입은 brewer.all() 참고
# family : 폰트
# savePlot(szWordCloudImageFile, type=”png”) : WordCloud 결과를 이미지 파일로 저장
