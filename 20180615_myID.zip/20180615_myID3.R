myID <- function(name, belongs, email){
  print(name)
  print(belongs)
  print(email)
}

name<-readline()
belongs<-readline()
email<-readline()

myID(name, belongs, email)
  