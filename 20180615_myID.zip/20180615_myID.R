print("Hayoung Oh")
print("Department of software and computer engineering")
print("hyoh79@gmail.com")