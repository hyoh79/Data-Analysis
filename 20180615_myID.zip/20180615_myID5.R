myID <- function(name, belongs, email){
  cat("*","\t\t",name,"\t\t\t  ","*\n")
  cat("*",belongs,"*\t\t\n")
  cat("*","\t\t",email,"\t\t","*\n")
}


name<-readline()
belongs<-readline()
email<-readline()

cat("****************************************************\n")
cat("*                                                  *\n")

myID(name, belongs, email)

cat("*                                                  *\n")
cat("****************************************************\n")
