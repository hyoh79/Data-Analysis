myID <- function(name, belongs, email){
  print("*","\t\t",name,"\t\t\t  ","*\n")
  # cat("*",belongs,"*\t\t\n")
  # cat("*","\t\t",email,"\t\t","*\n")
}


name<-readline()
# belongs<-readline()
# email<-readline()

cat("****************************************************\n")
cat("*                                                  *\n")

# myID(name, belongs, email)
myID(name)

cat("*                                                  *\n")
cat("****************************************************\n")
