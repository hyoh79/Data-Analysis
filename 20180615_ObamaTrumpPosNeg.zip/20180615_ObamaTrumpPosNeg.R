
rm(list=ls())
getwd()

# install.packages("ggplot2")
# install.packages("KoNLP")

library(ggplot2)
library(KoNLP)
library(plyr)
library(stringr)



# function score.sentiment 
score.sentiment = function(sentences, pos.words, neg.words, .progress='none') 
{ 
  # create simple array of scores with laply 
  scores = laply(sentences, 
                 function(sentence, pos.words, neg.words) 
                 { 
                   # remove punctuation 
                   sentence = gsub("[[:punct:]]", "", sentence) 
                   # remove control characters 
                   sentence = gsub("[[:cntrl:]]", "", sentence) 
                   # remove digits? 
                   sentence = gsub('\\d+', '', sentence) 
                   # remove html links 
                   sentence = gsub("http\\w+", "", sentence) 
                   # remove unnecessary spaces 
                   sentence = gsub("[ \t]{2,}", "", sentence) 
                   sentence = gsub("^\\s+|\\s+$", "", sentence)
                   # define error handling function when trying tolower 
                   tryTolower = function(x) 
                   { 
                     # create missing value 
                     y = NA 
                     # tryCatch error 
                     try_error = tryCatch(tolower(x), error=function(e) e) 
                     # if not an error 
                     if (!inherits(try_error, "error")) 
                       y = tolower(x) 
                     # result 
                     return(y) 
                   } 
                   # use tryTolower with sapply  
                   sentence = sapply(sentence, tryTolower) 
                   # split sentence into words with str_split (stringr package) 
                   word.list = str_split(sentence, "\\s+") 
                   words = unlist(word.list)
                   # compare words to the dictionaries of positive & negative terms 
                   pos.matches = match(words, pos.words) 
                   neg.matches = match(words, neg.words)
                   # get the position of the matched term or NA 
                   # we just want a TRUE/FALSE 
                   pos.matches = !is.na(pos.matches) 
                   neg.matches = !is.na(neg.matches)
                   # final score 
                   score = sum(pos.matches) - sum(neg.matches) 
                   return(score) 
                 }, pos.words, neg.words, .progress=.progress )
  # data frame with scores for each sentence 
  scores.df = data.frame(text=sentences, score=scores) 
  return(scores.df) 
} 

pos.words=scan("positive-words.txt", what="character", comment.char = ";")
neg.words=scan("negative-words.txt", what="character", comment.char = ";")



#pratice


#파일 입력 코드 시작

##txt파일로 넣고 싶을 때
##obama.txt 로 예제 수행

conn=file("obama.txt",open="r")
line=readLines(conn)
for (i in 1:length(line)){
  print(line[i])
}
close(conn)

#아래 문장 실행 전 주의사항 : txt의 양이 너무 많은 경우 영어 단어를 추출하는 함수는 pc의 ram이 낮을 시 
#작업시간이 오래걸리고 다운될 수도 있습니다.

X2<-sapply(line, extractNoun,USE.NAMES = T)
# X2<-sapply(line, extractNoun,USE.NAMES = F)

#list해제
c_vector<-unlist(X2)

#전처리 코드
#특수문자 공백처리
c_vector<-str_replace_all(c_vector,"[^[:alpha:]]","")

#공백이 아닌것만 저장
c_vector<-c_vector[c_vector!=""]

# [궁금] 원하는 관사와 비동사 빈도 확인
###a, the, is, am, are, be
# table(c_vector) dataframe 변환
X3<-as.data.frame(table(c_vector))
X3[X3$c=="a"|X3$c=="is"|X3$c=="the"|X3$c=="am"|X3$c=="are"|X3$c=="be",]


# [전처리 아직 진행 중...]
###a, the, is, am, are
#제거하고 싶은 관사나 비동사를 공백으로 변환함.
c_vector<-gsub("is","",c_vector)
c_vector<-gsub("the","",c_vector)
c_vector<-gsub("am","",c_vector)
c_vector<-gsub("are","",c_vector)

# The Number of Rows/Columns
NROW(c_vector)

#2자리이상만 추출
c_vector<-Filter(function(x){nchar(x)>2},c_vector)


# txt로 저장
write(c_vector,"ObamaFilter.txt")
H1<-read.table("ObamaFilter.txt")

#전처리 종료
str(H1)
wordcount<-table(H1)
H1
#감정점수 계산
results <- score.sentiment(H1$V1, pos.words, neg.words)
H1$score<-results$score
H1_mean<-mean(H1$score)
View(H1_mean)


H1_mean
#0.02071823
#obama

#H1_mean = line 문장의 감정점수
#H1_mean이 감정점수라고 볼 수 있음
#긍정단어 1개당 1점 부정단어 1개당 -1점
#최대값은 -1 ~ 1 사이의 값을 가지게 됨.



# rm(list=ls())
#리소스 회복을 위한 초기화


##trump 예제 시작

conn=file("trump.txt",open="r")
line=readLines(conn)
for (i in 1:length(line)){
  print(line[i])
}
close(conn)

#아래 문장 실행 전 주의사항 : txt의 양이 너무 많은 경우 영어 단어를 추출하는 
# 함수는 pc의 ram이 낮을 시 
#작업시간이 오래걸리고 다운될 수도 있습니다.

X2<-sapply(line, extractNoun,USE.NAMES = T)

#list해제
c<-unlist(X2)


#table(X2) dataframe 변환
X3<-as.data.frame(table(c))
X3[X3$c=="a"|X3$c=="is"|X3$c=="the"|X3$c=="am"|X3$c=="are"|X3$c=="be",]
#원하는 관사와 비동사 빈도 확인

###a, the, is, am, are, be


#전처리 코드

#2자리이상만 추출
c<-Filter(function(x){nchar(x)>2},c)

#특수문자 공백처리
#res<-str_replace_all(c,"[^[:alpha:]]","")
res<-c
#공백이 아닌것만 저장
res<-res[res!=""]

###a, the, is, am, are
#제거하고 싶은 관사나 비동사를 공백으로 변환함.
res<-gsub("is","",res)
res<-gsub("the","",res)
res<-gsub("am","",res)
res<-gsub("are","",res)

NROW(res)

#불필요한 단어를 공백처리하고 txt로 저장후 불러들이면 
# 공백이 없어진채로 들어오게됨.
write(res,"Trump_temp.txt")
H1_Trump<-read.table("Trump_temp.txt")

#전처리 종료
str(H1_Trump)
wordcountTrump<-table(H1_Trump)
View(H1_Trump)
#감정점수 계산


#위에 있는 score.sentiment 함수를 다시 수행하세요.
results_Trump <- score.sentiment(H1_Trump$V1, pos.words, neg.words)
H1_Trump$score<-results_Trump$score
H1_Tmean<-mean(H1_Trump$score)
View(H1_Tmean)

H1_Tmean
#0.04276069
#trump


obama_trump_score<-c(H1_mean,H1_Tmean)

windows()
barplot(obama_trump_score, col=rainbow(2), 
        xlab = "연설자(빨강: Obama, 파랑: Trump)", ylab = "연설물 긍정도")
title(main = "긍정도 비교(Obama vs. Trump)", font = 4)

#오바마와 트럼프의 연설문을 비교한 결과 트럼프가 긍정적인 
# 단어를 더 많이 언급한 것을 알 수 있음.

#steve.txt, bill.txt 등과 같이 다른 유명 인사문으로 바꿔서
# 넣으면 동일한 결과를 긍정도 분석가능합니다.
